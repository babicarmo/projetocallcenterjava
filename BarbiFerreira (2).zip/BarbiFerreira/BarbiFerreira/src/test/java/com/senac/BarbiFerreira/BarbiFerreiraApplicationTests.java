package com.senac.BarbiFerreira;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarbiFerreiraApplicationTests {

	@Test
	void contextLoads() {
	}

}
