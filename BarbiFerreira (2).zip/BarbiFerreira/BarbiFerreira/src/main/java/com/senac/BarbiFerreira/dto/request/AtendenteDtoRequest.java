package com.senac.BarbiFerreira.dto.request;


import jakarta.validation.constraints.NotBlank;


public class AtendenteDtoRequest {
    @NotBlank
    private String nome;

    @NotBlank
    private String usuarioLogin;

    @NotBlank
    private String chaveAcesso;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getUsuarioLogin() {
        return usuarioLogin;
    }

    public void setUsuarioLogin(String usuarioLogin) {
        this.usuarioLogin = usuarioLogin;
    }

    public String getChaveAcesso() {
        return chaveAcesso;
    }

    public void setChaveAcesso(String chaveAcesso) {
        this.chaveAcesso = chaveAcesso;
    }
}
