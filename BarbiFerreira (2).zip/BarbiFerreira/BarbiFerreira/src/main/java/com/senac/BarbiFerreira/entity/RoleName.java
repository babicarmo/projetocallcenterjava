package com.senac.BarbiFerreira.entity;

public enum RoleName {
    ADMINISTRATOR,
    CUSTOMER,
    ATENDENTE
}
