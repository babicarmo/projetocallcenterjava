package com.senac.BarbiFerreira;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BarbiFerreiraApplication {

	public static void main(String[] args) {
		SpringApplication.run(BarbiFerreiraApplication.class, args);
	}

}
