package com.senac.BarbiFerreira.controller;

import com.senac.BarbiFerreira.dto.request.AtendenteDtoRequest;
import com.senac.BarbiFerreira.dto.response.AtendenteDtoResponse;
import com.senac.BarbiFerreira.dto.response.RecoveryJwtTokenDto;
import com.senac.BarbiFerreira.entity.Atendente;
import com.senac.BarbiFerreira.service.AtendenteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/atendente")
@Tag(name="Atendente", description ="API para gerenciamento dos atendentes do sistema.")
public class AtendenteController {

    private final AtendenteService atendenteService;

    public AtendenteController(AtendenteService atendenteService) {
        this.atendenteService = atendenteService;
    }

    @GetMapping("/listar")
    @Operation(summary = "Listar todos os atendentes ativos")
    public ResponseEntity<List<Atendente>> listarTodos() {
        return ResponseEntity.ok(atendenteService.listarTodos());
    }

    @GetMapping("/listar/{id}")
    @Operation(summary = "Listar atendente pelo ID")
    public ResponseEntity<Atendente> listarPorId(@PathVariable Integer id) {
        Atendente atendente = atendenteService.listarPorId(id);
        return ResponseEntity.ok(atendente);
    }

    @PostMapping("/criar")
    @Operation(summary = "Criar um novo atendente")
    public ResponseEntity<AtendenteDtoResponse> criar(@Valid @RequestBody AtendenteDtoRequest dto) {
        AtendenteDtoResponse atendenteCriado = atendenteService.criarAtendente(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(atendenteCriado);
    }

    @PutMapping("/atualizar/{id}")
    @Operation(summary = "Atualizar os dados de um atendente")
    public ResponseEntity<AtendenteDtoResponse> atualizar(
            @PathVariable Integer id,
            @Valid @RequestBody AtendenteDtoRequest dto) {
        AtendenteDtoResponse atendenteAtualizado = atendenteService.atualizar(id, dto);
        return ResponseEntity.ok(atendenteAtualizado);
    }

    @PutMapping("/alterarStatus/{id}")
    @Operation(summary = "Alterar status de ativo de um atendente")
    public ResponseEntity<AtendenteDtoResponse> alterarStatus(
            @PathVariable Integer id,
            @RequestParam("ativo") int ativo) {
        AtendenteDtoResponse atendenteAtualizado = atendenteService.alterarStatus(id, ativo);
        return ResponseEntity.ok(atendenteAtualizado);
    }

    @DeleteMapping("/apagar/{id}")
    @Operation(summary = "Apagar (inativar) um atendente")
    public ResponseEntity<Void> apagar(@PathVariable Integer id) {
        atendenteService.apagar(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/login")
    @Operation(summary = "Autenticar atendente e retornar token JWT")
    public ResponseEntity<RecoveryJwtTokenDto> login(
            @RequestParam String usuarioLogin,
            @RequestParam String chaveAcesso) {
        RecoveryJwtTokenDto token = atendenteService.authenticateUser(usuarioLogin, chaveAcesso);
        return ResponseEntity.ok(token);
    }
}
