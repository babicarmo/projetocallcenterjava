package com.senac.BarbiFerreira.repository;

import com.senac.BarbiFerreira.entity.ChamadaAtendente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChamadaAtendenteRepository extends JpaRepository<ChamadaAtendente, Long> {
    List<ChamadaAtendente> findByAtendenteId(Long atendenteId);
}
