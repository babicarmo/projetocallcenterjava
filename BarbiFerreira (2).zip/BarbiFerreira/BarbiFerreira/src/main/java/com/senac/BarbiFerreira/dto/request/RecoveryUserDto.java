package com.senac.BarbiFerreira.dto.request;

public record RecoveryUserDto(

        Integer id,
        String nome,
        String usuarioLogin,
        Integer ativo

) {
}
