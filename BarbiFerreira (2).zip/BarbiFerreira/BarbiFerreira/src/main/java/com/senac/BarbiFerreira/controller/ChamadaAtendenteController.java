package com.senac.BarbiFerreira.controller;

import com.senac.BarbiFerreira.entity.ChamadaAtendente;
import com.senac.BarbiFerreira.service.ChamadaAtendenteService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/chamadas")
public class ChamadaAtendenteController {
    private final ChamadaAtendenteService service;

    public ChamadaAtendenteController(ChamadaAtendenteService service) {
        this.service = service;
    }

    // Criar nova chamada
    @PostMapping("/criar")
    public ResponseEntity<ChamadaAtendente> criarChamada(
            @RequestParam String descricao,
            @RequestParam Integer atendenteId) {
        ChamadaAtendente chamada = service.criarChamada(descricao, atendenteId);
        return ResponseEntity.ok(chamada);
    }

    // Listar todas as chamadas
    @GetMapping("/listar")
    public ResponseEntity<List<ChamadaAtendente>> listarChamadas() {
        return ResponseEntity.ok(service.listarTodasChamadas());
    }

    // Listar chamada por ID
    @GetMapping("/{id}")
    public ResponseEntity<ChamadaAtendente> listarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(service.listarPorId(id));
    }

    // Atualizar descrição da chamada
    @PutMapping("/atualizar/{id}")
    public ResponseEntity<ChamadaAtendente> atualizarDescricao(
            @PathVariable Long id,
            @RequestParam String descricao) {
        return ResponseEntity.ok(service.atualizarDescricao(id, descricao));
    }

    // Apagar chamada
    @DeleteMapping("/apagar/{id}")
    public ResponseEntity<Void> apagar(@PathVariable Long id) {
        service.apagarChamada(id);
        return ResponseEntity.noContent().build();
    }
}
