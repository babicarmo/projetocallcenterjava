package com.senac.BarbiFerreira.service;

import com.senac.BarbiFerreira.dto.request.AtendenteDtoRequest;
import com.senac.BarbiFerreira.dto.response.AtendenteDtoResponse;
import com.senac.BarbiFerreira.dto.response.RecoveryJwtTokenDto;
import com.senac.BarbiFerreira.entity.Atendente;
import com.senac.BarbiFerreira.entity.Role;
import com.senac.BarbiFerreira.entity.RoleName;
import com.senac.BarbiFerreira.repository.AtendenteRepository;
import com.senac.BarbiFerreira.repository.RoleRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

@Service
public class AtendenteService {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private AtendenteRepository repository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private JwtTokenService jwtTokenService;


    public AtendenteDtoResponse criarAtendente(AtendenteDtoRequest dto) {
        Atendente atendente = new Atendente();
        atendente.setNome(dto.getNome());
        atendente.setUsuarioLogin(dto.getUsuarioLogin());
        atendente.setChaveAcesso(dto.getChaveAcesso());
        atendente.setAtivo(1);
        atendente.setDataCriacao(LocalDateTime.now());


        Role roleAtendente = roleRepository.findByName(RoleName.ATENDENTE);
        if (roleAtendente != null) {
            atendente.setRoles(Collections.singletonList(roleAtendente));
        }

        Atendente atendenteSalvo = repository.save(atendente);
        return modelMapper.map(atendenteSalvo, AtendenteDtoResponse.class);
    }


    public List<Atendente> listarTodos() {
        return repository.findAll();
    }


    public Atendente listarPorId(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Atendente não encontrado"));
    }


    public AtendenteDtoResponse atualizar(Integer id, AtendenteDtoRequest dto) {
        Atendente atendente = listarPorId(id);

        atendente.setNome(dto.getNome());
        atendente.setUsuarioLogin(dto.getUsuarioLogin());
        atendente.setChaveAcesso(dto.getChaveAcesso());

        Atendente atualizado = repository.save(atendente);
        return modelMapper.map(atualizado, AtendenteDtoResponse.class);
    }


    public void apagar(Integer id) {
        Atendente atendente = listarPorId(id);
        atendente.setAtivo(0);
        repository.save(atendente);
    }


    public AtendenteDtoResponse alterarStatus(Integer id, int ativo) {
        Atendente atendente = listarPorId(id);
        atendente.setAtivo(ativo);

        Atendente atualizado = repository.save(atendente);
        return modelMapper.map(atualizado, AtendenteDtoResponse.class);
    }


    public RecoveryJwtTokenDto authenticateUser(String usuarioLogin, String chaveAcesso) {
        UsernamePasswordAuthenticationToken authToken =
                new UsernamePasswordAuthenticationToken(usuarioLogin, chaveAcesso);

        Authentication authentication = authenticationManager.authenticate(authToken);


        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();


        String token = jwtTokenService.generateToken(userDetails);


        return new RecoveryJwtTokenDto(token);
    }
}