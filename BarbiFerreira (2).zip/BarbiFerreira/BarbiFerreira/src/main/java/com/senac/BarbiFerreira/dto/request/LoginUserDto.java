package com.senac.BarbiFerreira.dto.request;

import lombok.Data;

@Data
public class LoginUserDto {
    private String matricula;
    private String chaveAcesso;
}
