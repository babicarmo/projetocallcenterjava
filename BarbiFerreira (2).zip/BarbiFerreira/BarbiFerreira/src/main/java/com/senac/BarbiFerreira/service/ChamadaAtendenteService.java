package com.senac.BarbiFerreira.service;

import com.senac.BarbiFerreira.entity.Atendente;
import com.senac.BarbiFerreira.entity.ChamadaAtendente;
import com.senac.BarbiFerreira.repository.AtendenteRepository;
import com.senac.BarbiFerreira.repository.ChamadaAtendenteRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ChamadaAtendenteService {
    private final ChamadaAtendenteRepository chamadaRepository;
    private final AtendenteRepository atendenteRepository;

    public ChamadaAtendenteService(ChamadaAtendenteRepository chamadaRepository,
                                   AtendenteRepository atendenteRepository) {
        this.chamadaRepository = chamadaRepository;
        this.atendenteRepository = atendenteRepository;
    }

    // Criar uma nova chamada
    public ChamadaAtendente criarChamada(String descricao, Integer atendenteId) {
        Atendente atendente = atendenteRepository.findById(atendenteId)
                .orElseThrow(() -> new RuntimeException("Atendente não encontrado"));

        ChamadaAtendente chamada = new ChamadaAtendente();
        chamada.setDescricao(descricao);
        chamada.setAtendente(atendente);
        chamada.setDataHora(LocalDateTime.now());

        return chamadaRepository.save(chamada);
    }

    // Listar todas as chamadas
    public List<ChamadaAtendente> listarTodasChamadas() {
        return chamadaRepository.findAll();
    }


    // Listar chamada por ID
    public ChamadaAtendente listarPorId(Long id) {
        return chamadaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Chamada não encontrada"));
    }

    // Atualizar descrição da chamada
    public ChamadaAtendente atualizarDescricao(Long id, String novaDescricao) {
        ChamadaAtendente chamada = listarPorId(id);
        chamada.setDescricao(novaDescricao);
        return chamadaRepository.save(chamada);
    }

    // Apagar chamada (lógico ou físico)
    public void apagarChamada(Long id) {
        ChamadaAtendente chamada = listarPorId(id);
        chamadaRepository.delete(chamada);
    }
}
