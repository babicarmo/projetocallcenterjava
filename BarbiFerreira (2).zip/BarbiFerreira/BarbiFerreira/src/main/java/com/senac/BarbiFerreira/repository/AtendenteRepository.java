package com.senac.BarbiFerreira.repository;

import com.senac.BarbiFerreira.entity.Atendente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface AtendenteRepository extends JpaRepository<Atendente, Integer> {
    @Query("SELECT a FROM Atendente a WHERE a.ativo >= 0")
    List<Atendente> listarAtendenteAtivos();

    @Query("SELECT a FROM Atendente a WHERE a.id = :id AND a.ativo >= 0")
    Atendente obterAtendenteAtivosPorId(@Param("id") int id);


    Optional<Atendente> findByUsuarioLogin(String usuarioLogin);
}
