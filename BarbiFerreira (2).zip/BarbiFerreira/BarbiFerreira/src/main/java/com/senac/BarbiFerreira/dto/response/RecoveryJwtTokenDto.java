package com.senac.BarbiFerreira.dto.response;


public record RecoveryJwtTokenDto(
        String token
) {

}
