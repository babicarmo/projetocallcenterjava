package com.senac.BarbiFerreira.service;

import com.senac.BarbiFerreira.entity.Atendente;
import com.senac.BarbiFerreira.repository.AtendenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class UserDetailsServiceImpl implements UserDetailsService {
    @Autowired
    private AtendenteRepository atendenteRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        Atendente atendente = atendenteRepository
                .findByUsuarioLogin(username)
                .orElseThrow(() -> new UsernameNotFoundException("Atendente não encontrado: " + username));

        return new UserDetailsImpl(atendente);
    }
}
